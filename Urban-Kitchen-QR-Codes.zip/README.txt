Urban Kitchen QR Codes

Urban-Kitchen-Selector-QR.png
https://urbankitchenbeverage.com/beverages/

Urban-Kitchen-Wine-QR.png
https://urbankitchenbeverage.com/wine.html

Urban-Kitchen-Whiskey-QR.png
https://urbankitchenbeverage.com/whiskey.html

Each PNG is 1200 x 1200 pixels with high error correction and was decoded after generation.